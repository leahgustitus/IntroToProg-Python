# Data code
objFileName = open("//Users//leahgustitus//Library//Mobile Documents//com~apple~CloudDocs//_PythonClass//Module06LeahGustitus//todo.txt", "r")
strData = ""
dicRow = {}
lstTable = []


#processing code
''' Open and read file'''
objFileName = open("//Users//leahgustitus//Library//Mobile Documents//com~apple~CloudDocs//_PythonClass//Module06LeahGustitus//todo.txt", "r")
for line in objFileName:
    strData = line.split(",")  # readline() reads a line of the data into 2 elements
    dicRow = {"Task": strData[0].strip(), "Priority": strData[1].strip()}
    lstTable.append(dicRow)
objFileName.close()

class Tasklist(object):
    @staticmethod
    def MenuOptions():
        '''Show menu options to user'''
        print("""
            Menu of Options
            1) Show current data
            2) Add a new item.
            3) Remove an existing item.
            4) Save Data to File
            5) Exit Program
            """)
        return

    @staticmethod
    def ChoiceOne():
        ''' shows items in list'''
        for index, item in enumerate(lstTable):
            print("{} - {}".format(index+1, item))
        return
    @staticmethod
    def ChoiceTwo():
        ''' adds new item to list'''
        newItem = input("Enter new item to add ")
        newPriority = input("Enter new priority ")
        lstTable.append({"Task": newItem, "Priority": newPriority})
        return lstTable

    @staticmethod
    def ChoiceThree():
        ''' removes item from list'''
        removeitem = int(input("What item number would you like to remove? "))
        del lstTable[removeitem - 1]
        return lstTable

    @staticmethod
    def ChoiceFour():
        ''' saves data to file'''
        objFileName = open("//Users//leahgustitus//Library//Mobile Documents//com~apple~CloudDocs//_PythonClass//Module06LeahGustitus//todo.txt", "w")
        for item in lstTable:
            for key, value in item.items():
                objFileName.write("{},{}\n".format(key, value))
        objFileName.close()
        print("Data saved")
        return

#Presentation Code
while(True):
    Tasklist.MenuOptions()
    strChoice = input("Which option would you like to perform? [1 to 5] - ")

    if (strChoice.strip() == '1'):
        Tasklist.ChoiceOne()

    elif (strChoice.strip() == '2'):
        Tasklist.ChoiceTwo()

    elif (strChoice.strip() == '3'):
        Tasklist.ChoiceThree()

    elif (strChoice.strip() == '4'):  # Step 6 - Save tasks to file
        Tasklist.ChoiceFour()

    elif (strChoice.strip() == '5'):
        break  # and Exit the program